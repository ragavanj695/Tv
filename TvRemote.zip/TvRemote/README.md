# TV Remote (Android TV / Google TV over WiFi)

1. Open this folder in Android Studio (File > Open) and let Gradle sync
   (it creates the Gradle wrapper; accept any AGP upgrade prompt).
2. Run on a real phone. Phone and TV must be on the same WiFi.
3. Pick your TV (or type its IP), then enter the 6-character code shown on the TV.
4. Use the remote. The pairing is remembered.

Protocol: Android TV Remote v2 (pairing on port 6467, control on 6466, TLS + protobuf).

## Build the APK in the cloud (no PC needed)
1. Create a GitHub repository and upload everything in this folder
   (including the hidden `.github` folder).
2. Open the repo's Actions tab. The "Build APK" workflow runs automatically.
3. When it finishes (about 5 minutes), open the run and download
   `TvRemote-apk` from Artifacts. Unzip it to get `app-debug.apk`.
