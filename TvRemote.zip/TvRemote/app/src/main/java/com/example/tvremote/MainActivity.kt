package com.example.tvremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App(vm: RemoteViewModel = viewModel()) {
    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
        when (vm.screen) {
            Screen.Devices -> DevicesScreen(vm)
            Screen.Code -> CodeScreen(vm)
            Screen.Remote -> RemoteScreen(vm)
        }
    }
}

@Composable
fun DevicesScreen(vm: RemoteViewModel) {
    var ip by remember { mutableStateOf("") }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Choose your TV", style = MaterialTheme.typography.headlineSmall)
        Text(vm.status)
        vm.devices.forEach { d ->
            OutlinedButton(onClick = { vm.pair(d.host) }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
                Text("${d.name}  (${d.host})")
            }
        }
        OutlinedTextField(
            value = ip,
            onValueChange = { ip = it },
            label = { Text("Or enter TV IP address") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { vm.pair(ip) }, enabled = !vm.busy && ip.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text("Pair")
        }
        TextButton(onClick = { vm.startScan() }) { Text("Scan again") }
    }
}

@Composable
fun CodeScreen(vm: RemoteViewModel) {
    var code by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Enter pairing code", style = MaterialTheme.typography.headlineSmall)
        Text("Type the 6-character code shown on your TV screen.")
        OutlinedTextField(
            value = code,
            onValueChange = { code = it.uppercase().filter { c -> c in "0123456789ABCDEF" }.take(6) },
            label = { Text("Code") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { vm.submitCode(code) }, enabled = code.length == 6 && !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text("Confirm")
        }
    }
}

@Composable
fun Key(label: String, code: Int, press: (Int) -> Unit, modifier: Modifier = Modifier) {
    FilledTonalButton(onClick = { press(code) }, modifier = modifier.height(56.dp)) { Text(label) }
}

@Composable
fun RemoteScreen(vm: RemoteViewModel) {
    val haptic = LocalHapticFeedback.current
    val press: (Int) -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        vm.key(it)
    }
    val row = Modifier.fillMaxWidth()
    val gap = Arrangement.spacedBy(8.dp)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(vm.status)
        if (!vm.connected) {
            Button(onClick = { vm.reconnect() }) { Text("Reconnect") }
        }
        Row(row, horizontalArrangement = gap) {
            Key("⏻ Power", 26, press, Modifier.weight(1f))
            Key("Input", 178, press, Modifier.weight(1f))
            Key("Mute", 164, press, Modifier.weight(1f))
        }

        // D-pad
        Key("▲", 19, press, Modifier.size(width = 96.dp, height = 64.dp))
        Row(horizontalArrangement = gap) {
            Key("◀", 21, press, Modifier.size(width = 96.dp, height = 64.dp))
            Key("OK", 23, press, Modifier.size(width = 96.dp, height = 64.dp))
            Key("▶", 22, press, Modifier.size(width = 96.dp, height = 64.dp))
        }
        Key("▼", 20, press, Modifier.size(width = 96.dp, height = 64.dp))

        Row(row, horizontalArrangement = gap) {
            Key("Back", 4, press, Modifier.weight(1f))
            Key("Home", 3, press, Modifier.weight(1f))
            Key("Menu", 82, press, Modifier.weight(1f))
        }
        Row(row, horizontalArrangement = gap) {
            Key("Vol +", 24, press, Modifier.weight(1f))
            Key("Ch +", 166, press, Modifier.weight(1f))
        }
        Row(row, horizontalArrangement = gap) {
            Key("Vol −", 25, press, Modifier.weight(1f))
            Key("Ch −", 167, press, Modifier.weight(1f))
        }
        Row(row, horizontalArrangement = gap) {
            Key("⏯ Play / Pause", 85, press, Modifier.weight(1f))
        }
        TextButton(onClick = { vm.changeTv() }) { Text("Change TV") }
    }
}
