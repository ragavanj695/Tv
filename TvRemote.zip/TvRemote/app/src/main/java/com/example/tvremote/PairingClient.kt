package com.example.tvremote

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.interfaces.RSAPublicKey
import javax.net.ssl.SSLSocket

/**
 * Android TV Remote v2 pairing (port 6467).
 * start() -> TV shows a 6-char hex code -> finish(code) proves we saw it.
 */
class PairingClient(private val host: String) {
    private var socket: SSLSocket? = null
    private lateinit var input: InputStream
    private lateinit var output: OutputStream

    private fun outer(fill: PbWriter.() -> Unit): ByteArray {
        val w = PbWriter()
        w.int(1, 2)      // protocol_version
        w.int(2, 200)    // status OK
        w.fill()
        return w.build()
    }

    private fun readOk(): PbReader {
        val r = PbReader(input.readFrame())
        if (r.ints[2] != 200L) throw IOException("TV rejected pairing (status ${r.ints[2]})")
        return r
    }

    fun start() {
        val s = TvTls.socket(host, 6467)
        socket = s
        input = s.inputStream
        output = s.outputStream

        // 1. pairing request
        output.writeFrame(outer { msg(10, PbWriter().str(1, "atvremote").str(2, "Phone Remote")) })
        readOk()

        // 2. options: we can type a 6-digit HEX code (encoding type 3)
        val encoding = PbWriter().int(1, 3).int(2, 6)
        output.writeFrame(outer { msg(20, PbWriter().msg(1, encoding).int(3, 1)) })
        readOk()

        // 3. configuration (role INPUT = 1). TV now displays the code.
        output.writeFrame(outer { msg(30, PbWriter().msg(1, encoding).int(2, 1)) })
        readOk()
    }

    fun finish(code: String): Boolean {
        val s = socket ?: return false
        if (code.length != 6) return false
        return try {
            val server = s.session.peerCertificates[0].publicKey as RSAPublicKey
            val client = TvTls.clientPublicKey()
            val codeBytes = ByteArray(3) { code.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

            val md = MessageDigest.getInstance("SHA-256")
            md.update(TvTls.modulus(client))
            md.update(TvTls.exponent(client))
            md.update(TvTls.modulus(server))
            md.update(TvTls.exponent(server))
            md.update(codeBytes.copyOfRange(1, 3))
            val hash = md.digest()
            if (hash[0] != codeBytes[0]) return false   // typed code is wrong

            output.writeFrame(outer { bytes(40, PbWriter().bytes(1, hash).build()) })
            val r = PbReader(input.readFrame())
            r.ints[2] == 200L && r.blobs.containsKey(41)
        } finally {
            close()
        }
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
    }
}
