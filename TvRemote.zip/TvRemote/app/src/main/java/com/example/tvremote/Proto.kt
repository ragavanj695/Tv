package com.example.tvremote

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Minimal protobuf writer (varint + length-delimited fields). */
class PbWriter {
    private val out = ByteArrayOutputStream()

    private fun varint(value: Long) {
        var x = value
        while ((x and 0x7FL.inv()) != 0L) {
            out.write(((x and 0x7FL) or 0x80L).toInt())
            x = x ushr 7
        }
        out.write(x.toInt())
    }

    fun int(field: Int, v: Long): PbWriter {
        varint((field shl 3).toLong()); varint(v); return this
    }

    fun int(field: Int, v: Int) = int(field, v.toLong())

    fun bytes(field: Int, b: ByteArray): PbWriter {
        varint(((field shl 3) or 2).toLong()); varint(b.size.toLong()); out.write(b); return this
    }

    fun str(field: Int, s: String) = bytes(field, s.toByteArray())
    fun msg(field: Int, w: PbWriter) = bytes(field, w.build())
    fun build(): ByteArray = out.toByteArray()
}

/** Minimal protobuf reader: keeps the last varint / blob seen for each field number. */
class PbReader(private val data: ByteArray) {
    val ints = HashMap<Int, Long>()
    val blobs = HashMap<Int, ByteArray>()
    private var pos = 0

    init {
        while (pos < data.size) {
            val tag = varint().toInt()
            val field = tag ushr 3
            when (tag and 7) {
                0 -> ints[field] = varint()
                1 -> pos += 8
                2 -> {
                    val len = varint().toInt()
                    blobs[field] = data.copyOfRange(pos, pos + len)
                    pos += len
                }
                5 -> pos += 4
                else -> throw IOException("Unsupported wire type")
            }
        }
    }

    private fun varint(): Long {
        var result = 0L
        var shift = 0
        while (true) {
            val b = data[pos++].toInt() and 0xFF
            result = result or ((b and 0x7F).toLong() shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
        }
        return result
    }
}

/** Messages on both TV ports are prefixed with a varint length. */
fun OutputStream.writeFrame(payload: ByteArray) {
    val w = ByteArrayOutputStream()
    var x = payload.size
    while (x > 0x7F) {
        w.write((x and 0x7F) or 0x80)
        x = x ushr 7
    }
    w.write(x)
    w.write(payload)
    write(w.toByteArray())
    flush()
}

fun InputStream.readFrame(): ByteArray {
    var len = 0
    var shift = 0
    while (true) {
        val b = read()
        if (b < 0) throw IOException("Connection closed")
        len = len or ((b and 0x7F) shl shift)
        if ((b and 0x80) == 0) break
        shift += 7
    }
    val buf = ByteArray(len)
    var off = 0
    while (off < len) {
        val n = read(buf, off, len - off)
        if (n < 0) throw IOException("Connection closed")
        off += n
    }
    return buf
}
