package com.example.tvremote

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class Screen { Devices, Code, Remote }

class RemoteViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tv", Context.MODE_PRIVATE)

    var screen by mutableStateOf(Screen.Devices); private set
    var status by mutableStateOf("Searching for TVs on your WiFi…"); private set
    var connected by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set
    val devices = mutableStateListOf<TvDevice>()

    private var discovery: TvDiscovery? = null
    private var pairing: PairingClient? = null
    private var remote: RemoteClient? = null
    private var remoteJob: Job? = null
    private var pairHost = ""

    init {
        val saved = prefs.getString("host", null)
        if (saved != null) connect(saved) else startScan()
    }

    fun startScan() {
        discovery?.stop()
        devices.clear()
        status = "Searching for TVs on your WiFi…"
        discovery = TvDiscovery(getApplication()) { d ->
            viewModelScope.launch(Dispatchers.Main) {
                if (devices.none { it.host == d.host }) devices.add(d)
            }
        }.also { it.start() }
        viewModelScope.launch {
            SubnetScanner.scan(getApplication()) { d ->
                viewModelScope.launch(Dispatchers.Main) {
                    if (devices.none { it.host == d.host }) devices.add(d)
                }
            }
            status = if (devices.isEmpty())
                "No TV found. Make sure TV is ON and on the same WiFi, or enter its IP below."
            else "Select your TV"
        }
    }

    fun pair(host: String) {
        val h = host.trim()
        if (h.isEmpty() || busy) return
        busy = true
        status = "Contacting TV…"
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val p = PairingClient(h)
                p.start()
                pairing = p
                pairHost = h
                status = "Enter the code shown on your TV"
                screen = Screen.Code
            } catch (e: Exception) {
                status = "Could not pair: ${e.message}"
            }
            busy = false
        }
    }

    fun submitCode(code: String) {
        if (busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (pairing?.finish(code.trim()) == true) {
                    prefs.edit().putString("host", pairHost).apply()
                    connect(pairHost)
                } else {
                    status = "Wrong code. Start pairing again."
                    screen = Screen.Devices
                }
            } catch (e: Exception) {
                status = "Pairing failed: ${e.message}"
                screen = Screen.Devices
            }
            busy = false
        }
    }

    fun connect(host: String) {
        discovery?.stop()
        remote?.close()
        remoteJob?.cancel()
        screen = Screen.Remote
        connected = false
        status = "Connecting…"
        val client = RemoteClient(host) { connected = true; status = "Connected" }
        remote = client
        remoteJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                client.run()
            } catch (e: Exception) {
                if (isActive) status = "Disconnected: ${e.message}"
            }
            connected = false
        }
    }

    fun reconnect() {
        prefs.getString("host", null)?.let { connect(it) }
    }

    fun key(code: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                remote?.sendKey(code)
            } catch (e: Exception) {
                connected = false
                status = "Send failed. Tap Reconnect."
            }
        }
    }

    fun changeTv() {
        remote?.close()
        remoteJob?.cancel()
        prefs.edit().remove("host").apply()
        connected = false
        screen = Screen.Devices
        startScan()
    }

    override fun onCleared() {
        discovery?.stop()
        pairing?.close()
        remote?.close()
    }
}
