package com.example.tvremote

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager

data class TvDevice(val name: String, val host: String)

/** Finds Android TVs on the local WiFi via mDNS (_androidtvremote2._tcp). */
class TvDiscovery(context: Context, private val onFound: (TvDevice) -> Unit) {
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var listener: NsdManager.DiscoveryListener? = null
    private val multicastLock = (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
        .createMulticastLock("tvremote").apply { setReferenceCounted(false) }

    fun start() {
        try { multicastLock.acquire() } catch (_: Exception) {}
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                synchronized(this@TvDiscovery) { queue.add(serviceInfo) }
                resolveNext()
            }
        }
        listener = l
        nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, l)
    }

    fun stop() {
        try { if (multicastLock.isHeld) multicastLock.release() } catch (_: Exception) {}
        listener?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        listener = null
    }

    // NsdManager can resolve only one service at a time.
    @Suppress("DEPRECATION")
    private fun resolveNext() {
        val next = synchronized(this) {
            if (resolving) null else queue.removeFirstOrNull()?.also { resolving = true }
        } ?: return
        nsd.resolveService(next, object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                synchronized(this@TvDiscovery) { resolving = false }
                resolveNext()
            }

            override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                synchronized(this@TvDiscovery) { resolving = false }
                serviceInfo.host?.hostAddress?.let { onFound(TvDevice(serviceInfo.serviceName, it)) }
                resolveNext()
            }
        })
    }
}
