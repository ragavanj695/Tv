package com.example.tvremote

import java.io.OutputStream
import javax.net.ssl.SSLSocket

/** Android TV Remote v2 control channel (port 6466). run() blocks until disconnected. */
class RemoteClient(
    private val host: String,
    private val onReady: () -> Unit
) {
    @Volatile private var socket: SSLSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var ready = false
    private val lock = Any()

    fun run() {
        val s = TvTls.socket(host, 6466)
        socket = s
        val input = s.inputStream
        out = s.outputStream
        try {
            while (true) {
                val r = PbReader(input.readFrame())
                when {
                    // TV sent its configuration -> answer with ours
                    r.blobs.containsKey(1) -> send(
                        PbWriter().msg(
                            1, PbWriter().int(1, 622).msg(
                                2, PbWriter()
                                    .str(1, "Android").str(2, "Phone")
                                    .int(3, 1).str(4, "1")
                                    .str(5, "com.example.tvremote").str(6, "1.0")
                            )
                        )
                    )
                    // TV asks us to activate
                    r.blobs.containsKey(2) -> send(PbWriter().msg(2, PbWriter().int(1, 622)))
                    // keep-alive ping
                    r.blobs.containsKey(8) -> {
                        val v = PbReader(r.blobs[8]!!).ints[1] ?: 0L
                        send(PbWriter().msg(9, PbWriter().int(1, v)))
                    }
                    // remote_start: handshake finished
                    r.blobs.containsKey(40) -> { ready = true; onReady() }
                }
            }
        } finally {
            ready = false
            close()
        }
    }

    /** direction 3 = SHORT press */
    fun sendKey(keyCode: Int) {
        if (!ready) return
        send(PbWriter().msg(10, PbWriter().int(1, keyCode).int(2, 3)))
    }

    private fun send(w: PbWriter) {
        val o = out ?: return
        synchronized(lock) { o.writeFrame(w.build()) }
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
    }
}
