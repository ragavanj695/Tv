package com.example.tvremote

import android.content.Context
import android.net.ConnectivityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket

/** Fallback finder: tries port 6466 on every address of the phone's WiFi subnet. */
object SubnetScanner {
    suspend fun scan(context: Context, onFound: (TvDevice) -> Unit) = withContext(Dispatchers.IO) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return@withContext
        val lp = cm.getLinkProperties(net) ?: return@withContext
        val ip = lp.linkAddresses.map { it.address }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { !it.isLoopbackAddress } ?: return@withContext
        val base = ip.hostAddress!!.substringBeforeLast('.')
        val sem = Semaphore(64)
        coroutineScope {
            (1..254).map { i ->
                async {
                    sem.withPermit {
                        val host = "$base.$i"
                        try {
                            Socket().use { it.connect(InetSocketAddress(host, 6466), 700) }
                            onFound(TvDevice("Android TV", host))
                        } catch (_: Exception) {
                        }
                    }
                }
            }.awaitAll()
        }
    }
}
